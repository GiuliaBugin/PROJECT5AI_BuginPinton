//
//  ViewController.swift
//  PROJECT5AI_buginPinton
//  Created by Giulia Bugin on 15/11/2018.
//
//  Copyright © 2018 Giulia Bugin. All rights reserved.
//
import UIKit
class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var area: UILabel!
    @IBOutlet weak var lato: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func fromStringToInt(stringa : String)  -> Int
{
    let intero:Int! = Int(stringa)
    return intero
}

    func calcolaAreaQuadrato(lato : Int) -> Double
{
    var lato2 = Double(lato)
    var area = pow(lato2, 2.0)
    return area
}
    @IBAction func controlla(_ sender: Any) {
        area.text = ""
        area.text = "AREA: " + String(calcolaAreaQuadrato(lato: fromStringToInt(stringa: lato.text!)));
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        lato.resignFirstResponder()
        return true
    }
    


}
